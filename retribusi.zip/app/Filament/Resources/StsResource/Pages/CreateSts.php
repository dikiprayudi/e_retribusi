<?php

namespace App\Filament\Resources\StsResource\Pages;

use App\Filament\Resources\StsResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateSts extends CreateRecord
{
    protected static string $resource = StsResource::class;
}
